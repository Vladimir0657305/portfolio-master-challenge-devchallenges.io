# Matrix animation using html5 canvas

A Pen created on CodePen.io. Original URL: [https://codepen.io/cpiscopo/pen/JjEwaW](https://codepen.io/cpiscopo/pen/JjEwaW).

This is not my work!

I'm starting out by experimenting with animations, and found this example on http://thecodeplayer.com/walkthrough/matrix-rain-animation-html5-canvas-javascript

/*
* Based on the animation
* by David Urbinati.
*
* Link to dribbble shot: 
* http://drbl.in/mBsi
*/